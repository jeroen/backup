library(testthat)
library(protolite)

test_check("protolite")
