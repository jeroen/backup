# unix

> Unix System Utilities

[![Build Status](https://travis-ci.org/jeroen/unix.svg?branch=master)](https://travis-ci.org/jeroen/unix)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/unix)](https://cran.r-project.org/package=unix)
[![CRAN RStudio mirror downloads](http://cranlogs.r-pkg.org/badges/unix)](https://cran.r-project.org/package=unix)
[![Github Stars](https://img.shields.io/github/stars/jeroen/unix.svg?style=social&label=Github)](https://github.com/jeroen/unix)

> Bindings to system utilities found in most Unix systems, 
  mainly POSIX functions which are not part of the Standard C Library.

