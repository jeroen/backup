# unix

> Unix System Utilities

[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/unix)](https://cran.r-project.org/package=unix)
[![CRAN RStudio mirror downloads](http://cranlogs.r-pkg.org/badges/unix)](https://cran.r-project.org/package=unix)

> Bindings to system utilities found in most Unix systems, 
  mainly POSIX functions which are not part of the Standard C Library.

