#include <Rconfig.h>
#ifdef WORDS_BIGENDIAN
#define BROTLI_BUILD_BIG_ENDIAN
#else
#define BROTLI_BUILD_LITTLE_ENDIAN
#endif
