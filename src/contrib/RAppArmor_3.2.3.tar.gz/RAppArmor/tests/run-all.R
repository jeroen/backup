# Comment out to disable unit tests at R CMD check
# library(testthat)
# test_check("RAppArmor")
